package com.dotadroid.dotadroid;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.ImageView;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.ImageView;
import android.widget.TextView;
/**
 * Created by matthewbennett on 07/05/15.
 */
public class SQLConnector extends AsyncTask<String,Void,String>{

        private TextView awr,sd,btm,wtm,ba,wa,nem;
        private ImageView i;
        private Context context;
        private Uri uri;

        //flag 0 means get and 1 means post.(By default it is get.)
        public SQLConnector(Context context,TextView awr,TextView sd, TextView btm, TextView wtm, TextView ba, TextView wa, TextView nem) {
            this.context = context;
            this.awr = awr;
            this.sd = sd;
            this.btm = btm;
            this.wtm = wtm;
            this.ba = ba;
            this.wa = wa;
            this.nem = nem;
        }

        protected void onPreExecute(){

        }
        @Override
        protected String doInBackground(String... arg0) {
            String average = "";
            try {

                String hero = (String) arg0[0];
                String link = "http://www.grogar.byethost6.com/averages.php?heroid="+hero;

                URL url = new URL(link);
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(link));
                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader (new InputStreamReader(response.getEntity().getContent()));
                StringBuffer sb = new StringBuffer("");
                String line = "";
                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }
                in.close();
                return sb.toString();

            }

            catch(Exception e){
                return new String("Exception = " + e.getMessage());
            }
        }

        //Image input found at http://stackoverflow.com/questions/3375166/android-drawable-images-from-url
        Bitmap drawable_from_url(String url) throws java.net.MalformedURLException, java.io.IOException {
            Bitmap x;

            HttpURLConnection connection = (HttpURLConnection)new URL(url) .openConnection();
            connection.setRequestProperty("User-agent","Mozilla/4.0");

            connection.connect();
            InputStream input = connection.getInputStream();

            x = BitmapFactory.decodeStream(input);
        return x;
        }

        @Override
        protected void onPostExecute(String result) {
        try {
            String[] test = result.split(";");
            this.awr.setText("Average Win Rate = " + test[0] + "%");
            this.sd.setText("Standard Deviation = " + test[1] + "%");
            this.btm.setText("Best Team Mate = " + getheroname(Integer.parseInt(test[2])));
            this.wtm.setText("Worst Team Mate = " + getheroname(Integer.parseInt(test[3])));
            this.ba.setText("Best Against = " + getheroname(Integer.parseInt(test[4])));
            this.wa.setText("Worst Against = " + getheroname(Integer.parseInt(test[5])));
            this.nem.setText("Nemesis = " + getheroname(Integer.parseInt(test[6])));
            this.i.setImageBitmap(drawable_from_url("http://www.grogar.byethost6.com/HERO_AVATARS/1.png"));
        }
        catch(Exception e){
            Log.d("Error: ", e.toString());
        }
        }

    public static String getheroname(int heroid){
        String heroname = "";
        switch (heroid){
            case 1: heroname = "Antimage"; break;
            case 2: heroname = "Axe"; break;
            case 3: heroname = "Bane"; break;
            case 4: heroname = "Bloodseeker"; break;
            case 5: heroname = "Crystal Maiden"; break;
            case 6: heroname = "Drow Ranger"; break;
            case 7: heroname = "Earthshaker"; break;
            case 8: heroname = "Juggernaught"; break;
            case 9: heroname = "Mirana"; break;
            case 10: heroname = "Morphling"; break;
            case 11: heroname = "Shadow Fiend"; break;
            case 12: heroname = "Phantom Lancer"; break;
            case 13: heroname = "Puck"; break;
            case 14: heroname = "Pudge"; break;
            case 15: heroname = "Razor"; break;
            case 16: heroname = "Sand King"; break;
            case 17: heroname = "Storm Spirit"; break;
            case 18: heroname = "Sven"; break;
            case 19: heroname = "Tiny"; break;
            case 20: heroname = "Vengeful Spirit"; break;
            case 21: heroname = "Windrunner"; break;
            case 22: heroname = "Zeus"; break;
            case 23: heroname = "Kunkka"; break;
            case 25: heroname = "Lina"; break;
            case 26: heroname = "Lion"; break;
            case 27: heroname = "Shadow Shaman"; break;
            case 28: heroname = "Slardar"; break;
            case 29: heroname = "Tidehunter"; break;
            case 30: heroname = "Witch Doctor"; break;
            case 31: heroname = "Lich"; break;
            case 32: heroname = "Riki"; break;
            case 33: heroname = "Enigma"; break;
            case 34: heroname = "Tinker"; break;
            case 35: heroname = "Sniper"; break;
            case 36: heroname = "Necrophos"; break;
            case 37: heroname = "Warlock"; break;
            case 38: heroname = "Beastmaster"; break;
            case 39: heroname = "Queen of Pain"; break;
            case 40: heroname = "Venomancer"; break;
            case 41: heroname = "Faceless Void"; break;
            case 42: heroname = "Wraith King"; break;
            case 43: heroname = "Death Prophet"; break;
            case 44: heroname = "Phantom Assassin"; break;
            case 45: heroname = "Pugna"; break;
            case 46: heroname = "Templar Assassin"; break;
            case 47: heroname = "Viper"; break;
            case 48: heroname = "Luna"; break;
            case 49: heroname = "Dragon Knight"; break;
            case 50: heroname = "Dazzle"; break;
            case 51: heroname = "Clockwerk"; break;
            case 52: heroname = "Leshrac"; break;
            case 53: heroname = "Nature's Prohpet"; break;
            case 54: heroname = "Lifestealer"; break;
            case 55: heroname = "Dark Seer"; break;
            case 56: heroname = "Clinkz"; break;
            case 57: heroname = "Omniknight"; break;
            case 58: heroname = "Enchantress"; break;
            case 59: heroname = "Huskar"; break;
            case 60: heroname = "Nightstalker"; break;
            case 61: heroname = "Broodmother"; break;
            case 62: heroname = "Bounty Hunter"; break;
            case 63: heroname = "Weaver"; break;
            case 64: heroname = "Jakiro"; break;
            case 65: heroname = "Batrider"; break;
            case 66: heroname = "Chen"; break;
            case 67: heroname = "Spectre"; break;
            case 68: heroname = "Doom"; break;
            case 69: heroname = "Ancient Apparition"; break;
            case 70: heroname = "Ursa"; break;
            case 71: heroname = "Spirit Breaker"; break;
            case 72: heroname = "Gyrocopter"; break;
            case 73: heroname = "Alchemist"; break;
            case 74: heroname = "Invoker"; break;
            case 75: heroname = "Silencer"; break;
            case 76: heroname = "Outworld Devourer"; break;
            case 77: heroname = "Lycan"; break;
            case 78: heroname = "Brewmaster"; break;
            case 79: heroname = "Shadow Demon"; break;
            case 80: heroname = "Lone Druid"; break;
            case 81: heroname = "Chaos Knight"; break;
            case 82: heroname = "Meepo"; break;
            case 83: heroname = "Treant Protector"; break;
            case 84: heroname = "Ogre Magi"; break;
            case 85: heroname = "Undying"; break;
            case 86: heroname = "Rubick"; break;
            case 87: heroname = "Disruptor"; break;
            case 88: heroname = "Nyx Assassin"; break;
            case 89: heroname = "Naga Siren"; break;
            case 90: heroname = "Keeper of the Light"; break;
            case 91: heroname = "Io"; break;
            case 92: heroname = "Visage"; break;
            case 93: heroname = "Slark"; break;
            case 94: heroname = "Medusa"; break;
            case 95: heroname = "Troll Warlord"; break;
            case 96: heroname = "Centaur Warrunner"; break;
            case 97: heroname = "Magnus"; break;
            case 98: heroname = "Timbersaw"; break;
            case 99: heroname = "Bristleback"; break;
            case 100: heroname = "Tusk"; break;
            case 101: heroname = "Skywrath Mage"; break;
            case 102: heroname = "Abaddon"; break;
            case 103: heroname = "Elder Titan"; break;
            case 104: heroname = "Legion Commander"; break;
            case 105: heroname = "Techies"; break;
            case 106: heroname = "Ember Spirit"; break;
            case 107: heroname = "Earth Spirit"; break;
            case 109: heroname = "Terrorblade"; break;
            case 110: heroname = "Phoenix"; break;
            case 111: heroname = "Oracle"; break;
        }
        return heroname;
    }

    public static String getheroID(String name){
        String id = "";

        for(int i=0; i < 111; i++){
            if(name.equals(getheroname(i))){
                id = Integer.toString(i);
            }
        }
        return id;
    }

    public static List<String> getAllHeroes(){
        List<String> allheroes = new ArrayList();
        for(int i = 1; i <= 111; i++){
            if(getheroname(i).equals("")){


            }
            else{
                allheroes.add(getheroname(i));
            }
        }
        return allheroes;
    }



}
