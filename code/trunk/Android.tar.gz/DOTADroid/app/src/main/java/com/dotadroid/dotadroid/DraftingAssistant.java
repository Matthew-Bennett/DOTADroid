package com.dotadroid.dotadroid;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.io.File;
import java.sql.*;
import java.util.*;
import android.view.View;
import android.widget.ImageView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;



//Large ammout of database connectivity taken from - http://www.tutorialspoint.com/android/android_php_mysql.htm
public class DraftingAssistant extends ActionBarActivity implements OnItemSelectedListener  {

    List allheroes =  getAllHeroes();
    Spinner heroes;
    private TextView awr, sd, btm, wtm, ba, wa, nem;
    private ImageView i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drafting_assistant);
        heroes = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, allheroes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        heroes.setAdapter(adapter);
        heroes.setOnItemSelectedListener(this);
        awr = (TextView) findViewById(R.id.awr);
        sd = (TextView) findViewById(R.id.sd);
        btm = (TextView) findViewById(R.id.btm);;
        wtm = (TextView) findViewById(R.id.wtm);
        ba = (TextView) findViewById(R.id.ba);
        wa = (TextView) findViewById(R.id.wa);
        nem = (TextView) findViewById(R.id.nem);


    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        try {
            new SQLConnector(this, awr, sd, btm, wtm, ba, wa, nem).execute(getheroID(parent.getItemAtPosition(position).toString()));
        }
        catch(Exception e){

        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_drafting_assistant, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Rounding method taken from @http://stackoverflow.com/questions/2808535/round-a-double-to-2-decimal-places
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    static Connection con = null;

    public static String getheroname(int heroid){
        String heroname = "";
        switch (heroid){
            case 1: heroname = "Antimage"; break;
            case 2: heroname = "Axe"; break;
            case 3: heroname = "Bane"; break;
            case 4: heroname = "Bloodseeker"; break;
            case 5: heroname = "Crystal Maiden"; break;
            case 6: heroname = "Drow Ranger"; break;
            case 7: heroname = "Earthshaker"; break;
            case 8: heroname = "Juggernaught"; break;
            case 9: heroname = "Mirana"; break;
            case 10: heroname = "Morphling"; break;
            case 11: heroname = "Shadow Fiend"; break;
            case 12: heroname = "Phantom Lancer"; break;
            case 13: heroname = "Puck"; break;
            case 14: heroname = "Pudge"; break;
            case 15: heroname = "Razor"; break;
            case 16: heroname = "Sand King"; break;
            case 17: heroname = "Storm Spirit"; break;
            case 18: heroname = "Sven"; break;
            case 19: heroname = "Tiny"; break;
            case 20: heroname = "Vengeful Spirit"; break;
            case 21: heroname = "Windrunner"; break;
            case 22: heroname = "Zeus"; break;
            case 23: heroname = "Kunkka"; break;
            case 25: heroname = "Lina"; break;
            case 26: heroname = "Lion"; break;
            case 27: heroname = "Shadow Shaman"; break;
            case 28: heroname = "Slardar"; break;
            case 29: heroname = "Tidehunter"; break;
            case 30: heroname = "Witch Doctor"; break;
            case 31: heroname = "Lich"; break;
            case 32: heroname = "Riki"; break;
            case 33: heroname = "Enigma"; break;
            case 34: heroname = "Tinker"; break;
            case 35: heroname = "Sniper"; break;
            case 36: heroname = "Necrophos"; break;
            case 37: heroname = "Warlock"; break;
            case 38: heroname = "Beastmaster"; break;
            case 39: heroname = "Queen of Pain"; break;
            case 40: heroname = "Venomancer"; break;
            case 41: heroname = "Faceless Void"; break;
            case 42: heroname = "Wraith King"; break;
            case 43: heroname = "Death Prophet"; break;
            case 44: heroname = "Phantom Assassin"; break;
            case 45: heroname = "Pugna"; break;
            case 46: heroname = "Templar Assassin"; break;
            case 47: heroname = "Viper"; break;
            case 48: heroname = "Luna"; break;
            case 49: heroname = "Dragon Knight"; break;
            case 50: heroname = "Dazzle"; break;
            case 51: heroname = "Clockwerk"; break;
            case 52: heroname = "Leshrac"; break;
            case 53: heroname = "Nature's Prohpet"; break;
            case 54: heroname = "Lifestealer"; break;
            case 55: heroname = "Dark Seer"; break;
            case 56: heroname = "Clinkz"; break;
            case 57: heroname = "Omniknight"; break;
            case 58: heroname = "Enchantress"; break;
            case 59: heroname = "Huskar"; break;
            case 60: heroname = "Nightstalker"; break;
            case 61: heroname = "Broodmother"; break;
            case 62: heroname = "Bounty Hunter"; break;
            case 63: heroname = "Weaver"; break;
            case 64: heroname = "Jakiro"; break;
            case 65: heroname = "Batrider"; break;
            case 66: heroname = "Chen"; break;
            case 67: heroname = "Spectre"; break;
            case 68: heroname = "Doom"; break;
            case 69: heroname = "Ancient Apparition"; break;
            case 70: heroname = "Ursa"; break;
            case 71: heroname = "Spirit Breaker"; break;
            case 72: heroname = "Gyrocopter"; break;
            case 73: heroname = "Alchemist"; break;
            case 74: heroname = "Invoker"; break;
            case 75: heroname = "Silencer"; break;
            case 76: heroname = "Outworld Devourer"; break;
            case 77: heroname = "Lycan"; break;
            case 78: heroname = "Brewmaster"; break;
            case 79: heroname = "Shadow Demon"; break;
            case 80: heroname = "Lone Druid"; break;
            case 81: heroname = "Chaos Knight"; break;
            case 82: heroname = "Meepo"; break;
            case 83: heroname = "Treant Protector"; break;
            case 84: heroname = "Ogre Magi"; break;
            case 85: heroname = "Undying"; break;
            case 86: heroname = "Rubick"; break;
            case 87: heroname = "Disruptor"; break;
            case 88: heroname = "Nyx Assassin"; break;
            case 89: heroname = "Naga Siren"; break;
            case 90: heroname = "Keeper of the Light"; break;
            case 91: heroname = "Io"; break;
            case 92: heroname = "Visage"; break;
            case 93: heroname = "Slark"; break;
            case 94: heroname = "Medusa"; break;
            case 95: heroname = "Troll Warlord"; break;
            case 96: heroname = "Centaur Warrunner"; break;
            case 97: heroname = "Magnus"; break;
            case 98: heroname = "Timbersaw"; break;
            case 99: heroname = "Bristleback"; break;
            case 100: heroname = "Tusk"; break;
            case 101: heroname = "Skywrath Mage"; break;
            case 102: heroname = "Abaddon"; break;
            case 103: heroname = "Elder Titan"; break;
            case 104: heroname = "Legion Commander"; break;
            case 105: heroname = "Techies"; break;
            case 106: heroname = "Ember Spirit"; break;
            case 107: heroname = "Earth Spirit"; break;
            case 109: heroname = "Terrorblade"; break;
            case 110: heroname = "Phoenix"; break;
            case 111: heroname = "Oracle"; break;
        }
        return heroname;
    }

    public static String getheroID(String name){
        String id = "";

        for(int i=0; i < 111; i++){
            if(name.equals(getheroname(i))){
                id = Integer.toString(i);
            }
        }
        return id;
    }

    public static List<String> getAllHeroes(){
        List<String> allheroes = new ArrayList();
        for(int i = 1; i <= 111; i++){
            if(getheroname(i).equals("")){


            }
            else{
                allheroes.add(getheroname(i));
            }
        }
        return allheroes;
    }


}
